#!/bin/bash
set -x

string="\rStart\r"
echo -e "$string"

# Change directory to /home/certigeni
cd /home/certigeni
if [ $? -ne 0 ]; then
  echo "Error: Failed to change directory to /home/certigeni"
  exit 1
fi

# Start the FastAPI app
echo "Starting FastAPI app..."
exec uvicorn main:app --host 0.0.0.0

string="\rDone\r"
echo -e "$string"

set +x
